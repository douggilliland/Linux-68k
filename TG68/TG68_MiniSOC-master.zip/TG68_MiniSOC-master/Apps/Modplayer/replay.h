#ifndef REPLAY_H
#define REPLAY_H

void mt_init(unsigned char *mt_data);
void mt_music(void);
int ptBuddyPlay(unsigned char *modData, char timerType);
void ptBuddyClose(void);

#endif

