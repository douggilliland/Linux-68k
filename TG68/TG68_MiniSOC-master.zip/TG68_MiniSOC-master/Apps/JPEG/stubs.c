
#include <stdarg.h>

int fprintf(const char *fmt,...)
{
	return(0);
}

char *getenv(const char *name)
{
	return(0);
}

void *_impure_ptr;
